"""Mahzen command extensions."""
