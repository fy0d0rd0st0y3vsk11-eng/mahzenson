"""Mahzen Discord bot package."""
