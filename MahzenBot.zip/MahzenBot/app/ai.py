import aiohttp

class OpenRouterClient:
    def __init__(self, api_key: str, model: str, site_url: str = "", app_name: str = "Mahzen Bot"):
        self.api_key = api_key
        self.model = model
        self.site_url = site_url
        self.app_name = app_name

    async def ask(self, prompt: str) -> str:
        if not self.api_key:
            return "OpenRouter ayarlanmamış. Hosting paneline OPENROUTER_API_KEY ekle."
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "X-Title": self.app_name,
        }
        if self.site_url:
            headers["HTTP-Referer"] = self.site_url
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": "Sen Mahzen Discord sunucusunun yardımcı asistanısın. Türkçe, nazik ve faydalı yanıt ver."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0.7,
            "max_tokens": 500,
        }
        timeout = aiohttp.ClientTimeout(total=35)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.post("https://openrouter.ai/api/v1/chat/completions", headers=headers, json=payload) as response:
                if response.status == 401:
                    return "OpenRouter anahtarı kabul edilmedi. API anahtarını kontrol et."
                if response.status == 402:
                    return "OpenRouter hesabında bu istek için kullanılabilir kredi görünmüyor."
                if response.status == 429:
                    return "OpenRouter istek sınırına ulaşıldı. Biraz sonra tekrar dene."
                if response.status >= 500:
                    return "OpenRouter şu anda hata veriyor. Biraz sonra tekrar dene."
                response.raise_for_status()
                data = await response.json()
        choices = data.get("choices", [])
        if not choices:
            return "OpenRouter boş yanıt döndürdü."
        content = choices[0].get("message", {}).get("content", "")
        if not isinstance(content, str) or not content.strip():
            return "OpenRouter okunabilir bir yanıt döndürmedi."
        return content.strip()[:1900]
